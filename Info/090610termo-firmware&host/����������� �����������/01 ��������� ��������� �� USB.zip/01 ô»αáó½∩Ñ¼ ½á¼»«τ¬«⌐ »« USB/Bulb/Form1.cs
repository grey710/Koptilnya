﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AvrUsbDevice;

namespace Bulb
{
    public partial class Form1 : Form
    {
        bool ledOn = false;
        ushort vid = 0x16C0, pid = 0x05DC;
        ATMega16 dev;
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dev = new ATMega16(vid, pid);
            if (!dev.IsOpen())
            {
                MessageBox.Show(String.Format("Невозможно найти устройство vid = 0x{0:X}, pid = 0x{1:X}", vid, pid),
                                              "Ошибка USB", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Close();
            }
            dev.DDRB |= 0x01;   // Бит 0 порта B - на вывод
            dev.DDRD |= 0x20;   // Бит 5 порта D - на вывод
            dev.PORTB &= 0xFE;  // Выключим светодиодик на плате
            dev.PORTD |= 0x20;  // Подадим 1 на PD5, т.е. потушим лампочку
        }

        private void buttonOnOff_Click(object sender, EventArgs e)
        {
            ledOn = !ledOn;
            if (ledOn)
            {
                dev.PORTB |= 0x01;  // Включим светодиодик на плате
                dev.PORTD &= 0xDF;  // Подадим 0 на PD5 - включим лампочку
                panel1.BackColor = Color.Red;
            }
            else
            {
                dev.PORTB &= 0xFE;  // Выключим светодиодик на плате
                dev.PORTD |= 0x20;  // Подадим 1 на PD5 - выключим лампочку
                panel1.BackColor = Color.LightYellow;
            }
        }
    }
}
