﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AvrUsbDevice;
using ZedGraph;
using System.IO;

namespace Thermo
{
    public partial class Form1 : Form
    {
        ushort vid = 0x16C0, pid = 0x05DC;
        ATMega16 dev;

        byte dm;                // Количество датчиков, обнаруженных на шине
        double t, t0, t1, ts;   // Температуры: текущая, окружающей среды, термостата, уставка
        double dtm = 14;        // Ширина зоны пропорциональности
        double err;             // Текущая невязка
        double kq;              // Коэффициент для компенсатора потерь на охлаждение
        DateTime tim0;          // Время начала процесса
        string info1, info2;    // Вспомогательные строки для вывода текущей информации

        int valICR1 = 31250;    // Это число заносится в регистр ICR1 и определяет период ШИМ-сигнала.
        // Тактовая частота процессора делится на 256. 
        // В результате период получится около 1 сек
        double k;               // Коэффициент для перевода % мощности в значение регистра OCR1A

        #region Переменные для ZedGraph
        Color gc = Color.LightGray;
        GraphPane pane;
        PointPairList aList;
        LineItem aCurve;
        #endregion

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dev = new ATMega16(vid, pid);
            if (!dev.IsOpen())
            {
                MessageBox.Show(String.Format("Невозможно найти устройство vid = 0x{0:X}, pid = 0x{1:X}", vid, pid),
                                              "Ошибка USB", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Close();
            }
            else
            {
                tim0 = DateTime.Now;
                timer1sec.Start();
                ts = (double)numericUpDownTt.Value;
                kq = (double)numericUpDownComp.Value;

                dev.DDRB |= 0x01;   // Бит 0 порта B - на вывод
                dev.DDRD |= 0x20;   // Бит 5 порта D - на вывод
                dev.DDRB &= 0xFD;   // !!!! Костылик для 1-Wire !!!!

                dev.PORTB &= 0xFE;  // Выключим светодиодик на плате
                dev.PORTD |= 0x20;  // Подадим 1 на PD5, т.е. выключим нагреватель
                dev.PORTB &= 0xFD;  // !!!! Костылик для 1-Wire !!!!

                #region Инициализация TIMER1 в режием ШИМ (Phase and Frequency Correct)
                dev.DDRD = 0x20;                        // PD5 (OC1A) - выход ШИМ TIMER1
                dev.TCCR1B = 0x00;                      // Остановим таймер

                // Нам нужен обратный ШИМ, чтобы при нулевой мощности на выходе была 1,
                // так, чтобы симистор был закрыт    
                dev.TCCR1A = (1 << ATMega16.COM1A1) |
                             (1 << ATMega16.COM1A0);    // Здесь WGM11, WGM10 = 0 для режима 8 см. ниже
                dev.TCCR1B = (1 << ATMega16.WGM13) |    // WGM13 = 1, WGM12 = 0 - это режим 8 : PWM, Phase and Frequency Correct
                             0x04;                      // Тактовая частота делится на 256
                dev.ICR1H = (byte)(valICR1 >> 8);
                dev.ICR1L = (byte)(valICR1 & 0xFF);

                dev.OCR1AH = 0x00;
                dev.OCR1AL = 0x00;

                k = valICR1 / 100.0;
                #endregion

                #region Инициализация ZedGraph
                pane = zedGraphControl.GraphPane;
                pane.Title.IsVisible = false;
                pane.Fill = new Fill(Color.Black);
                pane.Chart.Fill = new Fill(Color.Black);
                pane.Chart.Border.Color = gc;

                pane.XAxis.Title.Text = "Время, мин";
                pane.XAxis.Title.FontSpec.FontColor = gc;
                pane.XAxis.Title.FontSpec.IsBold = false;
                pane.XAxis.Scale.MaxAuto = true;
                pane.XAxis.Scale.FontSpec.Size = 12;
                pane.XAxis.MajorGrid.IsVisible = true;
                pane.XAxis.Color = gc;
                pane.XAxis.Scale.FontSpec.FontColor = gc;
                pane.XAxis.MajorGrid.Color = gc;

                pane.YAxis.Title.Text = "Температура,°C";
                pane.YAxis.Title.FontSpec.FontColor = gc;
                pane.YAxis.Title.FontSpec.IsBold = false;
                //                pane.YAxis.Scale.Min = 0;
                //                pane.YAxis.Scale.Max = 120;
                pane.YAxis.Scale.FontSpec.Size = 12;
                pane.YAxis.MajorGrid.IsVisible = true;
                pane.YAxis.Color = gc;
                pane.YAxis.Scale.FontSpec.FontColor = gc;
                pane.YAxis.MajorGrid.Color = gc;

                pane.YAxis.ScaleFormatEvent += new Axis.ScaleFormatHandler(YScaleFormatEvent);

                aList = new PointPairList();
                aCurve = pane.AddCurve("", aList, Color.Orange, SymbolType.None);

                pane.YAxis.MajorGrid.IsZeroLine = false;
                zedGraphControl.AxisChange();
                #endregion
            }
        }

       public string YScaleFormatEvent(GraphPane pane, Axis axis, double val, int index)
        {
            return val.ToString("f2");
        }

       private void Form1_FormClosing(object sender, FormClosingEventArgs e)
       {
           if (dev.IsOpen())
               SetPower(0);
       }

       private void SetPower(int pp)        // Установка мощности нагревателя (pp - проценты от номинала)
        {
            int v = (int)(k * pp);
            dev.OCR1AH = (byte)(v >> 8);
            dev.OCR1AL = (byte)v;
        }

       private void timer1sec_Tick(object sender, EventArgs e)
       {
           int ht;                          // Нужная мощность нагревателя в процентах от номинала
           double q = kq * (t1 - t0);       // Компенсация тепловых потерь за 1 сек

           dm = dev.OWSearchAll();          // Ищем датчики на шине 1-wire
           if (dm < 2)
           {
               toolStripStatusLabelInfo.Text = "Нет одного или более датчиков";
               return;
           }

           dev.OWReset();                   // Общий сброс
           dev.OWCommand(0x44);             // Запуск преобразования на всех датчиках
           timer750ms.Start();              // Запускаем таймер на 750 мс - это время преобразования DS18X20,
                                            // дальнейшая работа с данными - в timer750ms_Tick()

           if (!checkBoxOnOff.Checked)      // Термостат выключен
               return;
           err = ts - t1;                   // Невязка

           if (err < 0)                     // Греть не нужно
           {
               ht = 0;
               panelInd.BackColor = Color.Green;
           }
           else                             // Будем греть...
           {
               if (err >= dtm)              // Еще вне зоны пропорциональности - полная мощность
                   ht = 100;
               else                         // Мощность пропорциональна невязке
               {
                   ht = (int)((100 * err) / dtm) + (int)q;
                   if (ht > 100)
                       ht = 100;
               }
               panelInd.BackColor = Color.Red;
           }


           info2 = ";     err = " + err.ToString("f2") + ";   ht = " + ht.ToString() + "%";
           toolStripStatusLabelInfo.Text = info1 + info2;

           SetPower(ht);                    // Говорим ШИМ-генератору что нам нужно...
       }

       private void timer750ms_Tick(object sender, EventArgs e)
       {
           timer750ms.Stop();
           for (byte i = 0; i < dm; i++)               // Опрашиваем все датчики по порядку
           {
               dev.OWReset();                          // Сброс, как обычно
               dev.OWCommand(0xBE, i);                 // Команда чтения результата i-го датчика
               ushort w = dev.OWReadByte();            // Читаем сначала младший байт
               w |= (ushort)(dev.OWReadByte() << 8);   // Читаем и добавим к слову старший байт
               bool negFlag = ((w & 0x1000) != 0);     // Признак отрицательной температуры
               if (negFlag)                            // Вычислим модуль
                   w = (ushort)(65536 - w);
               // Из 4 младших бит формируем дробную часть
               double dt = (((w & 0x0008) != 0) ? 0.5 : 0) +
                           (((w & 0x0004) != 0) ? 0.25 : 0) +
                           (((w & 0x0002) != 0) ? 0.125 : 0) +
                           (((w & 0x0001) != 0) ? 0.0625 : 0);
               t = ((double)(w >> 4)) + dt;
               if (negFlag)                            // Теперь учтем знак
                   t = -t;

               if (i == 0) // В данном случае датчик термостата идет самым первым
                   t1 = t;
               else        // А второй (и, возможно, остальные) - датчик температры окружающей среды
                   t0 = t;
           }


           TimeSpan ts = DateTime.Now - tim0;
           double ctim = ts.Hours * 60 + ts.Minutes + (ts.Seconds + ts.Milliseconds * 0.001d) / 60.0; // Время - в минутах
           info1 = "Время процесса = " + ctim.ToString("f2") + " мин; " +
                   "Окр. среда T0 = " + t0.ToString("f2") +
                   "°C; Термостат T1 = " + t1.ToString("f2") + "°C";
           toolStripStatusLabelInfo.Text = info1 + info2;

           if (checkBoxOnOff.Checked)                  // Термостат включен - рисуем график
           {
               aList.Add(ctim, t1);                    // Добавим точку на график
               zedGraphControl.AxisChange();
               zedGraphControl.Refresh();
           }
           else // Термостат успели выключить за время оцифровки температуры - все выключим
           {
               panelInd.BackColor = Color.Black;
               SetPower(0);
           }
       }

       private void buttonSave_Click(object sender, EventArgs e)
       {
           StreamWriter sw;
           string s = "";
           if (saveFileDialog.ShowDialog() == DialogResult.OK)
           {
               foreach (PointPair pp in aList)
                   s += pp.X.ToString("f2") + "\t" + pp.Y.ToString("f2") + "\r\n";

               using (sw = new StreamWriter(saveFileDialog.FileName, false, Encoding.UTF8))
               {
                   sw.Write(s);
                   sw.Close();
               }
           }
       }

       private void numericUpDownTt_ValueChanged(object sender, EventArgs e)
       {
           ts = (double)numericUpDownTt.Value;
       }

       private void numericUpDownProp_ValueChanged(object sender, EventArgs e)
       {
           // Скорректируем ширину зоны пропорциональности, коль пользователь того хочет
           dtm = (double)numericUpDownProp.Value;
       }

       private void checkBoxOnOff_CheckedChanged(object sender, EventArgs e)
       {
           if (checkBoxOnOff.Checked)   // Включили термостат
           {
               tim0 = DateTime.Now;
               aList.Clear();          // Очистим график
               zedGraphControl.AxisChange();
               zedGraphControl.Refresh();
               timerGlobal.Start();
           }
       }

       private void timerGlobal_Tick(object sender, EventArgs e)
       {
           // Пример простой программы водяной бани - ступенчатый подъем температуры от 40° до 80° 
           // с шагом 20° и последующим естественным остыванием до 50° и дальнейшим поддержанием этой т-ры
           // Длительность каждой ступени - 20 мин. Это время задается таймером timerGlobal
           double tsl = (double)numericUpDownTt.Value;
           tsl += 20;
           if (tsl > 80)   // Все, доехали до максимума. Пусть теперь остывает...
           {
               tsl = 50;
               timerGlobal.Stop(); // Больше этот таймер не нужен.
           }
           numericUpDownTt.Value = (decimal)tsl;
           numericUpDownTt_ValueChanged(sender, e);
       }

       private void numericUpDownComp_ValueChanged(object sender, EventArgs e)
       {
           kq = (double)numericUpDownComp.Value;
       }
    }
}
