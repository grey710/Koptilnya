﻿namespace Thermostat
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.numericUpDownTt = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonSave = new System.Windows.Forms.Button();
            this.panelInd = new System.Windows.Forms.Panel();
            this.checkBoxOnOff = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabelInfo = new System.Windows.Forms.ToolStripStatusLabel();
            this.zedGraphControl = new ZedGraph.ZedGraphControl();
            this.timer1sec = new System.Windows.Forms.Timer(this.components);
            this.timer750ms = new System.Windows.Forms.Timer(this.components);
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.timerGlobal = new System.Windows.Forms.Timer(this.components);
            this.numericUpDownProp = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTt)).BeginInit();
            this.statusStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownProp)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.numericUpDownProp);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.numericUpDownTt);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.buttonSave);
            this.panel1.Controls.Add(this.panelInd);
            this.panel1.Controls.Add(this.checkBoxOnOff);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(672, 27);
            this.panel1.TabIndex = 11;
            // 
            // numericUpDownTt
            // 
            this.numericUpDownTt.DecimalPlaces = 1;
            this.numericUpDownTt.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numericUpDownTt.Location = new System.Drawing.Point(129, 3);
            this.numericUpDownTt.Name = "numericUpDownTt";
            this.numericUpDownTt.Size = new System.Drawing.Size(51, 20);
            this.numericUpDownTt.TabIndex = 8;
            this.numericUpDownTt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDownTt.Value = new decimal(new int[] {
            40,
            0,
            0,
            0});
            this.numericUpDownTt.ValueChanged += new System.EventHandler(this.numericUpDownTt_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(78, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Уставка";
            // 
            // buttonSave
            // 
            this.buttonSave.Location = new System.Drawing.Point(5, 2);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(69, 23);
            this.buttonSave.TabIndex = 11;
            this.buttonSave.Text = "Сохранить";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // panelInd
            // 
            this.panelInd.BackColor = System.Drawing.Color.Black;
            this.panelInd.Location = new System.Drawing.Point(509, 3);
            this.panelInd.Name = "panelInd";
            this.panelInd.Size = new System.Drawing.Size(24, 22);
            this.panelInd.TabIndex = 10;
            // 
            // checkBoxOnOff
            // 
            this.checkBoxOnOff.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBoxOnOff.AutoSize = true;
            this.checkBoxOnOff.Location = new System.Drawing.Point(433, 2);
            this.checkBoxOnOff.Name = "checkBoxOnOff";
            this.checkBoxOnOff.Size = new System.Drawing.Size(72, 23);
            this.checkBoxOnOff.TabIndex = 9;
            this.checkBoxOnOff.Text = "Термостат";
            this.checkBoxOnOff.UseVisualStyleBackColor = true;
            this.checkBoxOnOff.CheckedChanged += new System.EventHandler(this.checkBoxOnOff_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(179, 7);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(18, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "°C";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabelInfo});
            this.statusStrip1.Location = new System.Drawing.Point(0, 371);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(672, 22);
            this.statusStrip1.TabIndex = 12;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabelInfo
            // 
            this.toolStripStatusLabelInfo.Name = "toolStripStatusLabelInfo";
            this.toolStripStatusLabelInfo.Size = new System.Drawing.Size(0, 17);
            // 
            // zedGraphControl
            // 
            this.zedGraphControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.zedGraphControl.Location = new System.Drawing.Point(0, 27);
            this.zedGraphControl.Name = "zedGraphControl";
            this.zedGraphControl.ScrollGrace = 0;
            this.zedGraphControl.ScrollMaxX = 0;
            this.zedGraphControl.ScrollMaxY = 0;
            this.zedGraphControl.ScrollMaxY2 = 0;
            this.zedGraphControl.ScrollMinX = 0;
            this.zedGraphControl.ScrollMinY = 0;
            this.zedGraphControl.ScrollMinY2 = 0;
            this.zedGraphControl.Size = new System.Drawing.Size(672, 344);
            this.zedGraphControl.TabIndex = 13;
            // 
            // timer1sec
            // 
            this.timer1sec.Interval = 1000;
            this.timer1sec.Tick += new System.EventHandler(this.timer1sec_Tick);
            // 
            // timer750ms
            // 
            this.timer750ms.Interval = 750;
            this.timer750ms.Tick += new System.EventHandler(this.timer750ms_Tick);
            // 
            // saveFileDialog
            // 
            this.saveFileDialog.DefaultExt = "*.txt";
            this.saveFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            // 
            // timerGlobal
            // 
            this.timerGlobal.Interval = 1200000;
            this.timerGlobal.Tick += new System.EventHandler(this.timerGlobal_Tick);
            // 
            // numericUpDownProp
            // 
            this.numericUpDownProp.DecimalPlaces = 1;
            this.numericUpDownProp.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.numericUpDownProp.Location = new System.Drawing.Point(345, 3);
            this.numericUpDownProp.Name = "numericUpDownProp";
            this.numericUpDownProp.Size = new System.Drawing.Size(51, 20);
            this.numericUpDownProp.TabIndex = 13;
            this.numericUpDownProp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDownProp.Value = new decimal(new int[] {
            14,
            0,
            0,
            0});
            this.numericUpDownProp.ValueChanged += new System.EventHandler(this.numericUpDownProp_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(200, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 13);
            this.label2.TabIndex = 14;
            this.label2.Text = "Зона пропорциональности";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(401, 7);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(18, 13);
            this.label4.TabIndex = 15;
            this.label4.Text = "°C";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(672, 393);
            this.Controls.Add(this.zedGraphControl);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thermostat - пропорциональный регулятор";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTt)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownProp)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.NumericUpDown numericUpDownTt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox checkBoxOnOff;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelInfo;
        private ZedGraph.ZedGraphControl zedGraphControl;
        private System.Windows.Forms.Timer timer1sec;
        private System.Windows.Forms.Timer timer750ms;
        private System.Windows.Forms.Panel panelInd;
        private System.Windows.Forms.Button buttonSave;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.Windows.Forms.Timer timerGlobal;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown numericUpDownProp;
        private System.Windows.Forms.Label label2;
    }
}

