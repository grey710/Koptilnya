﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AvrUsbDevice;

namespace PWM
{
    public partial class Form1 : Form
    {
        ushort vid = 0x16C0, pid = 0x05DC;
        ATMega16 dev;           // Класс-обертка для работы с ATMega16 через USB

        int valICR1 = 31250;    // Это число заносится в регистр ICR1 и определяет период ШИМ-сигнала.
                                // Тактовая частота процессора делится на 256. 
                                // В результате период получится около 1 сек
        double k;               // Коэффициент для перевода % мощности в значение регистра OCR1A
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dev = new ATMega16(vid, pid);
            if (!dev.IsOpen()) // С USB что-то не так...
            {
                MessageBox.Show(String.Format("Невозможно найти устройство vid = 0x{0:X}, pid = 0x{1:X}", vid, pid),
                                              "Ошибка USB", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Close();
            }
            else    // С USB все в порядке
            {
                #region Инициализация TIMER1 в режием ШИМ (Phase and Frequency Correct)
                dev.DDRD = 0x20;                        // PD5 (OC1A) - выход ШИМ TIMER1
                dev.TCCR1B = 0x00;                      // Остановим таймер

                // Нам нужен обратный ШИМ, чтобы при нулевой мощности на выходе была 1,
                // так, чтобы симистор был закрыт    
                dev.TCCR1A = (1 << ATMega16.COM1A1) |
                             (1 << ATMega16.COM1A0);    // Здесь WGM11, WGM10 = 0 для режима 8 см. ниже
                dev.TCCR1B = (1 << ATMega16.WGM13) |    // WGM13 = 1, WGM12 = 0 - это режим 8 : PWM, Phase and Frequency Correct
                             0x04;                      // Тактовая частота делится на 256
                dev.ICR1H = (byte)(valICR1 >> 8);
                dev.ICR1L = (byte)(valICR1 & 0xFF);

                dev.OCR1AH = 0x00;
                dev.OCR1AL = 0x00;

                k = valICR1 / 100.0;
                #endregion
            }
        }

        private void numericUpDownPower_ValueChanged(object sender, EventArgs e)
        {
            // При изменении мощности - обновляем содержимое регистра OCR1AH - скважность ШИМ-импульсов
            // (в данном случае - длительность пауз, между импульсами)
            int v = (int)(k * ((double)numericUpDownPower.Value));
            dev.OCR1AH = (byte)(v >> 8);
            dev.OCR1AL = (byte)v;
        }

        private void buttonMin_Click(object sender, EventArgs e)
        {
            numericUpDownPower.Value = 0;
        }

        private void buttonMax_Click(object sender, EventArgs e)
        {
            numericUpDownPower.Value = 100;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            numericUpDownPower.Value = 0;
        }
    }
}
